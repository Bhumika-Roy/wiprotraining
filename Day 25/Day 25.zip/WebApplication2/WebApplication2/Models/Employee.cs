﻿using System.Reflection;

namespace WebApplication2.Models
{
    public class Employee
    {
        public int empid { get; set; }

        public string Firstname { get; set; }
        public string lastname { get; set; }
        public string city { get; set; }
    }
}