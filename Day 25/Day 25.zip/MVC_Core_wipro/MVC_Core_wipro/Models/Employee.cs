﻿namespace MVC_Core_wipro.Models
{
    public class Employee
    {
        public int empid { get; set; }

        public string firstname { get; set; }

        public string lastname { get; set; }

        public string city { get; set; }
    }
}
